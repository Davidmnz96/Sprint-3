import os

import yagmail as yagmail
from flask import Flask, render_template, flash, request, redirect, url_for
import utils

app = Flask(__name__)
app.secret_key = os.urandom(24)

@app.route('/')
def index():
    return render_template('index.html')



@app.route('/login', methods=('GET', 'POST'))
def login():
    try:
        if request.method=='POST':
            
            correo=request.form['correo']
            password=request.form['password']
            error=None

            if not utils.isEmailValid(correo):
                error = 'Correo invalido'
                flash(error)
                print(error)

            if not utils.isPasswordValid(password):
                error = 'La contraseña debe contener al menos una minúscula, una mayúscula, un número y 8 caracteres'
                flash(error)
                print(error)

            if error is not None:
                return render_template('login.html')
                print("todo mal")
            else:
                #modificar la siguiente linea con tu informacion personal
                yag = yagmail.SMTP('wpprueba.prueba0123456@gmail.com', 'prue0123%&/') 
                yag.send(to=correo, subject='Activa tu cuenta',
                        contents='Bienvenido, usa este link para activar tu cuenta ')
                flash('Revisa tu correo para activar tu cuenta')
                return render_template('consultas.html')
                print("todo bien")

        return render_template('login.html')
    except:
       return render_template('login.html')
    

@app.route('/registro', methods=('GET', 'POST'))
def signup():
    # try:
    #     if request.method=='POST':
            
    #         correo=request.form['correo']
    #         password=request.form['password']
    #         error=None

    #         if not utils.isEmailValid(correo):
    #             error = 'Correo invalido'
    #             flash(error)
    #             print(error)

    #         if not utils.isPasswordValid(password):
    #             error = 'La contraseña debe contener al menos una minúscula, una mayúscula, un número y 8 caracteres'
    #             flash(error)
    #             print(error)

    #         if error is not None:
    #             return render_template("registro.html")
    #             print("todo mal")
    #         else:
    #             #modificar la siguiente linea con tu informacion personal
    #             yag = yagmail.SMTP('wpprueba.prueba0123456@gmail.com', 'prue0123%&/') 
    #             yag.send(to=correo, subject='Activa tu cuenta',
    #                     contents='Bienvenido, usa este link para activar tu cuenta ')
    #             flash('Revisa tu correo para activar tu cuenta')
    #             return render_template('login.html')
    #             print("todo bien")

    #     return render_template('registro.html')
    # except:
       return render_template('registro.html')


@app.route('/consultas')
def consultas():
    return render_template('consultas.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/reservar')
def reservar():
    return render_template('reservar.html')

@app.route('/crearvuelo')
def crearvuelo():
    return render_template('crearvuelo.html')

@app.route('/eliminarvuelo')
def eliminarvuelo():
    return render_template('eliminarvuelo.html')

@app.route('/editarvuelo')
def editarvuelo():
    return render_template('editarvuelo.html')

@app.route('/evaluar')
def evaluar():
    return render_template('evaluar.html')